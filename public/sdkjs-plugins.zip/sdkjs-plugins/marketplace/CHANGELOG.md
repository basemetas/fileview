# Change Log

## 1.0.0

* Initial release.

## 1.0.1

* Add loader.
* Fix problem with internet checking.
* Fix problem for Windows XP.

## 1.0.2

* Enable plugin for viewer mode.
* Add button and new window for developer mode.
* Rename window for notification when removeing plugin into desktop.

## 1.0.3

* Add "pdf" to the supported editors.

## 1.0.4

* Change developer window (add warnign - bug 66451).

## 1.0.5

* Fix problem into desktop with deletting manually installed plugins.