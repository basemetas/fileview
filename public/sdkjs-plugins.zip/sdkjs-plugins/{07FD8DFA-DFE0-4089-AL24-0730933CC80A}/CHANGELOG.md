# Change Log

## 1.0.0

* Initial release.

## 1.0.1

* Add translations for Japan and Chine languages.
* Improve work with images.

## 1.0.2

* Update jquery version.