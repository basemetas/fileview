# Change Log

## 1.0.0

* Initial release.

## 1.0.1

* Add translations for Japan and Chine languages.

## 1.0.2

* Othet improvements.

## 1.0.3

* Change working for viewer mode.

## 1.0.4

* Add message that service isn't available in user region (if we have problem with loading necessary data).