# Change Log

## 1.0.0

* Initial release.

## 2.0.0

* Use TesserectJS v4
* IE11 support has been discontinued

## 2.0.1

* Fix problem with styles for language select.
* Add sorting for languages in alphabetical order.

## 2.0.2

* Update jquery version.