# Change Log

## 1.0.0

* Initial release.

## 1.0.1

* Some visual changes.

## 1.0.2

* Fix problem some problems.

## 1.0.3

* Fix problem with google services.

## 1.0.4

* Change working for viewer mode.
* Disable plugin for IE.
* Bug Fix

## 1.0.5

* Add "pdf" to the supported editors.

## 1.0.6

* Add message, that plugin doesn't work in user region (if we have some problems with loading necessary data).

## 1.0.7

* Fix problem of repeated translation of the same text.

## 1.0.8

* Update jquery version.