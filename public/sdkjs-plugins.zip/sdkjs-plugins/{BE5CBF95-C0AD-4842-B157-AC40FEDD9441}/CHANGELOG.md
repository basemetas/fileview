# Change Log

## 1.0.0

* Initial release.

## 1.0.1

* Add translations for Japan and Chine languages.
* Other improvements.

## 1.0.2

* Change resources for locales files.

## 1.0.3

* Add notification that this plugin doesn't work into desktop.