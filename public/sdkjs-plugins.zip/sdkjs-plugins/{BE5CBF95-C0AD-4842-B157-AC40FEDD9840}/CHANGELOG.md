# Change Log

## 1.0.0

* Initial release.

## 1.0.1

* Change working for viewer mode.

## 1.0.2

* Add "pdf" to the supported editors.

## 1.0.3

* Update jquery version.