# Change Log

## 1.0.0

* Initial release.

## 1.0.1

* Add translations for Japan and Chine languages.
* Add librarys for code autoformating.
* Other improvements.

# 1.0.2

* Disable plugin for IE.

## 1.0.3

* Update jquery version.