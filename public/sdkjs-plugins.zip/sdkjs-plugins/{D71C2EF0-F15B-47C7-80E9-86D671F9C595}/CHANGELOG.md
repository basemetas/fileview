# Change Log

## 1.0.0

* Initial release.

## 1.0.1

* Add translations for Japan and Chine languages.

## 2.0.0

* Bug fix.

## 2.0.1

* Add "pdf" to the supported editors.

## 2.0.2

* Update jquery version.