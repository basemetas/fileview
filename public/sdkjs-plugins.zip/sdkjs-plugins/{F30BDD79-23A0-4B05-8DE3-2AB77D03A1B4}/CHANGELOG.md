# Change Log

## 1.0.0

* Initial release.

## 1.0.1

* Disable plugin for viewer.

## 1.0.2

* Bug fix. Now plugin will paste text with current cursor position formatting.
* Add notification that plugin doesn't work into desktop.
* Add check for safari browser (plugin works only in Chrome).

## 1.0.3

* Update jquery version.